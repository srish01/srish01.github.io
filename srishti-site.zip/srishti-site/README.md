# srish01.github.io

Personal academic website of Srishti Gupta.

## Publish on GitHub Pages

1. Create a public repository named exactly `srish01.github.io`.
2. Upload `index.html`, `cv.pdf` and your photo as `profile.jpg` (square, at least 300 x 300 px).
3. In the repository, open Settings > Pages and set Source to "Deploy from a branch", branch `main`, folder `/ (root)`.
4. After a minute the site is live at https://srish01.github.io.

## Updating

- New paper: copy one `<article class="pub">` block in `index.html` and edit it.
- New CV: replace `cv.pdf`.
- No photo yet: the page shows your initials until `profile.jpg` exists.
